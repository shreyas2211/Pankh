<footer class="probootstrap-footer probootstrap-bg">
        <div class="container">
          <div class="row">
            <div class="col-md-4 probootstrap-animate">
              <div class="probootstrap-footer-widget">
                <h3>About Us</h3>
                <p>Pankh foundation is efforts to educate people</p>
                <ul class="probootstrap-footer-social">
                  <li><a href="<?php echo $twitter_link ?>"><i class="icon-twitter"></i></a></li>
                  <li><a href="<?php echo $facebook_link;; ?>"><i class="icon-facebook"></i></a></li>
                  <li><a href="<?php echo $instagram_link; ?>"><i class="icon-instagram"></i></a></li>
                  <li><a href="<?php echo $linkedin_link; ?>"><i class="icon-linkedin"></i></a></li>
                  <li><a href="<?php echo $youtube_link; ?>"><i class="icon-youtube"></i></a></li>
                </ul>
              </div>
            </div>
           
            <div class="col-md-4 probootstrap-animate">
              <div class="probootstrap-footer-widget">
                <h3>Contact Info</h3>
                <ul class="probootstrap-contact-info">
                  <li><i class="icon-location2"></i> <span><?php echo $address; ?></span></li>
                  <li><i class="icon-mail"></i><span><?php echo $email; ?></span></li>
                  <li><i class="icon-phone2"></i><span><?php echo $phone; ?></span></li>
                </ul>
                
              </div>
            </div>

            <div class="col-md-4 probootstrap-animate">
              <div class="probootstrap-footer-widget">
                <h3>Donation</h3>
                <p>All donations made to PANKH Foundation are exempt under the section 80G of the income-tax act of India.</p>
                <p><a href="#" class="btn btn-primary">Donate Now</a></p>
              </div>
            </div>
           
          </div>
          <!-- END row -->
          
        </div>

        <div class="probootstrap-copyright">
          <div class="container">
            <div class="row">
              <div class="col-md-8 text-left">
                <p>&copy; 2022 . All Rights Reserved. Designed &amp; Developed with <i class="icon icon-heart"></i> by Tirth Patel</a></p>
              </div>
              <div class="col-md-4 probootstrap-back-to-top">
                <p><a href="#" class="js-backtotop">Back to top <i class="icon-arrow-long-up"></i></a></p>
              </div>
            </div>
          </div>
        </div>
      </footer>

    <script src="js/scripts.min.js"></script>
    <script src="js/main.min.js"></script>
    <script src="js/custom.js"></script>
    
  </body>
</html>