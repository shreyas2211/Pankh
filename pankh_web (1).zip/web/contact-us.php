<?php include 'header.php'; ?>


<div class="tb-space"></div>

<div class="container">
    <section class="probootstrap-section">
        <div class="container">
            <div class="col-md-12 text-center section-heading probootstrap-animate" data-animate-effect="fadeIn">
                <h2>Contact Us</h2>
                <p class="lead">feel free to conatct us</p>
            </div>
            <div class="row">
                <div class="col-md-6">
                <form action="#" method="post" class="probootstrap-form">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email">
                    </div>
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" class="form-control" id="subject" name="subject">
                    </div>
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea cols="30" rows="10" class="form-control" id="message" name="message"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary btn-block btn-lg" id="submit" name="submit" value="Send Message">
                    </div>

                    <?php
              
              if(isset($_POST['submit'])){

                if(isset($_POST['name'], $_POST['email'], $_POST['subject']))
                {
                  $name = $_POST['name'];
                  $email = $_POST['email'];
                  $subject = $_POST['subject'];
                  $message = $_POST['message'];
                  
                  $sql = "INSERT INTO contact (name,email,subject,message) VALUES (:name,:email,:subject,:message)";
                  $query = $dbConn->prepare($sql);
                  $query->bindparam(':name', $name);
                  $query->bindparam(':email', $email);
                  $query->bindparam(':subject', $subject);
                  $query->bindparam(':message', $message);
                  $checkm = $query->execute();
                  if($checkm){
                    echo "<script>alert('Your message is submitted successfully.');</script>";
                    

                  }
                  else{
                    echo "<script>alert('Your message is not submitted.');</script>";
                  }
                }
                else{
                  echo "plese fill all fields";
                }
                
                $dbConn = null;    
                
              }
              else{
                
              }

              unset($_POST['submit']);

            ?>

                </form>
                </div>
                <div class="col-md-6 col-md-push-1 probootstrap-animate">
                        <h4>Contact People</h4>
                        <ul class="probootstrap-contact-info">
                        <li><i class="icon-location"></i> <span><?php echo $address; ?></span></li>
                        <li><i class="icon-email"></i><span><?php echo $email; ?></span></li>
                        <li><i class="icon-phone"></i><span><?php echo $phone; ?></span></li>
                        </ul>     
                </div>
          </div>
        </div>
    </section>
</div>

<?php include 'footer.php';?>