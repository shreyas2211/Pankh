-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2022 at 09:51 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pankh_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `name` mediumtext NOT NULL,
  `email` mediumtext NOT NULL,
  `subject` mediumtext NOT NULL,
  `message` longtext NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `image_id` int(10) NOT NULL,
  `image_description` varchar(250) DEFAULT NULL,
  `image` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`image_id`, `image_description`, `image`) VALUES
(1, 'image 1', 'wm_enlarge_N1WotEGw (2).jpg'),
(2, 'image 2', 'wm_enlarge_N1WotEGw (3).jpg');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `pro_id` int(10) NOT NULL,
  `pro_name` varchar(250) DEFAULT NULL,
  `file` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `time` varchar(250) NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`pro_id`, `pro_name`, `file`, `description`, `time`) VALUES
(1, 'Help Children To Get Food', '3160714 - Data Mining [VisionPapers.in].pdf', 'dasdkjaskdjaksldjlkdjdaskdjadjsadlk', '2022-02-27'),
(2, 'Help Children To Get Education', '3130007_ Indian Constitution_16052019_075252AM.pdf', 'we should educate childrens', '2022-02-27'),
(3, 'Help Children To Get better Health', '3130004_03062019_085738AM.pdf', 'we should organize health camp', '2022-02-27 14:18:54'),
(4, 'Help Children To Get cloths', '3130704_03062019_082327AM.pdf', 'we collect cloths for childrens', '2022-02-27 14:20:56');

-- --------------------------------------------------------

--
-- Table structure for table `site_setting`
--

CREATE TABLE `site_setting` (
  `s_id` int(10) NOT NULL,
  `s_field_name` varchar(250) NOT NULL,
  `s_field_value` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `site_setting`
--

INSERT INTO `site_setting` (`s_id`, `s_field_name`, `s_field_value`) VALUES
(1, 'about_short', 'Aim of Pankh Foundation is to educate homeless children and providing them healthy food, cloths, books, toys, and other necessary things. our team efforts to provide teaching them on every sunday'),
(2, 'address', 'Savan surface, Sadhuvasvani Road, Rajkot'),
(3, 'phone', '5977375883'),
(4, 'email', 'pankh@gmail.com'),
(5, 'facebook_link', 'https://facebook.in'),
(6, 'instagram_link', 'https://instagram.in'),
(7, 'twitter_link', 'https://twitter.in'),
(8, 'linkedin_link', 'https://linkedin.in'),
(9, 'youtube_link', 'https://youtube.in');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `u_id` int(10) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `phone` int(12) NOT NULL,
  `city` varchar(250) NOT NULL,
  `state` varchar(250) NOT NULL,
  `dob` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`u_id`, `email`, `password`, `username`, `phone`, `city`, `state`, `dob`) VALUES
(1, 'tirth@pankh.org', 'passwork', 'tirth', 0, '', '', ''),
(2, 'admin@pankh.org\r\n', 'admin', 'admin', 0, '', '', ''),
(3, 'tirthmakati2987@gmail.com', 'pass', 'raghu', 99490959, 'rajkot', 'gujarat', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`pro_id`);

--
-- Indexes for table `site_setting`
--
ALTER TABLE `site_setting`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `image_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `pro_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `site_setting`
--
ALTER TABLE `site_setting`
  MODIFY `s_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `u_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
