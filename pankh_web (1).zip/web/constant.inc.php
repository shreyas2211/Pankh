<?php 

    $dbHost = 'localhost';
    $dbName = 'pankh_project';
    $dbUser = 'root';
    $dbPasw = '';

    //database connection
    $conn = mysqli_connect($dbHost,$dbUser,$dbPasw,$dbName);

	try {
		$dbConn = new PDO("mysql:host={$dbHost};dbname={$dbName}", $dbUser, $dbPasw);
		$dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch(PDOException $e) {
		echo $e->getMessage();
	}

	// about_short
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 1 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
		$about_short =  $row['s_field_value'];
	}
	
	// address
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 2 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
		$address =  $row['s_field_value'];
	}

	// phone
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 3 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $phone =  $row['s_field_value'];
	}

	// email
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 4 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $email =  $row['s_field_value'];
	}
	
	// facebook_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 5 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$facebook_link =  $row['s_field_value'];
	}

	// instagram_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 6 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $instagram_link =  $row['s_field_value'];
	}

	// twitter_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 7 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$twitter_link =  $row['s_field_value'];
	}

	// linkedin_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 8 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$linkedin_link =  $row['s_field_value'];
	}

	// youtube_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 9 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$youtube_link =  $row['s_field_value'];
	}

?>