<?php 
require '../module/header.php';
    
    $user = $_SESSION['username'];
    $qwr="SELECT * FROM users WHERE username = '$user'";
    $run=mysqli_query($conn,$qwr);
	$row = mysqli_fetch_array($run);
        $username = $row['username'];
        $password = $row['password'];
        $id = $row['u_id'];
?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Profile Setting</h2>
	</div>
	<div>
    <div class="login-wrap d-flex align-items-center flex-wrap justify-content-center ">

            <div class="card-body container align-center col-sm-12">   
                <form method="post" action="#">
                    <div class="card-text control-group row">
                        <label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>username</b></label>
                        <div class="col-sm-12 col-md-10">
                            <input type="text" value="<?php echo $username; ?>" name="username" data-original-title="" class="form-control" required>
                        </div>
                    </div><br>
                    <div class="card-text control-group row">
                        <label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>password</b></label>
                        <div class="col-sm-12 col-md-10">
                            <input type="text" value="<?php echo $password; ?>" name="password" data-original-title="" class="form-control" required>
                        </div>
                    </div><br>
                    <button class="btn btn-primary btn-block" name="update">update</button>
                </form>    
            </div>
    </div>
</div>

<?php

if(isset($_POST['update'])){
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    $query = "UPDATE `users` SET `username`= '$username' , `password` = '$password'  where id = '$id' ";
    $run=mysqli_query($conn,$query);
}


require '../module/footer.php';
?>