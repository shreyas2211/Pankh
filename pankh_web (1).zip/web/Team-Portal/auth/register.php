<?php
	 session_start();
	require '../module/config.php';

	if(isset($_POST["submit"]))  
      {  
           if(empty($_POST["name"]) || empty($_POST["email"]) || empty($_POST["phone"]) || empty($_POST["city"]) || empty($_POST["state"]) || empty($_POST["password"]))  
           {  
                $message = '<label>All fields are required</label>';  
           }  
           else  
           {  
               $username= $_POST["name"];
               $email = $_POST["email"];
               $phone = $_POST["phone"];
               $city = $_POST["city"];
               $state = $_POST["state"];
               $password = $_POST["password"];

                $query = "INSERT INTO `users`(`username`, `email`,`password`, `phone`,`city`, `state`) VALUES ('$username', '$email','$password', '$phone','$city', '$state') ";
                $run = mysqli_query($conn,$query);
        
                if ($run==true) 
                {
                    echo "<script>alert('user registered sucessfully');</script>";
                    echo '<script type="text/javascript"> window.location.href = "index.php";</script>';
                }
                else{
                    echo "<script>alert('user can't registrer');</script>";
                } 
           }  
		}	   
?>


<!DOCTYPE html>
<html>
<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">
	<title>Pankh Team Portal</title>

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/style.css">


	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag(){dataLayer.push(arguments);}
		gtag('js', new Date());

		gtag('config', 'UA-119386393-1');
	</script>
</head>
<body>
	<div class="login-header box-shadow">
		<div class="container-fluid d-flex justify-content-between align-items-center">
			<div class="brand-logo">
				<a href="../index.php">
					<img src="../Assets/image/pankh_origanl.jpg" style="width: 70%;" alt="">
				</a>
			</div>
			<div class="login-menu">
				<ul>
					<li><a href="../index.php">Pankh Team Portal</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="login-wrap d-flex align-items-center flex-wrap justify-content-center">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-12">
					<div class="login-box bg-white box-shadow border-radius-10">
						<div class="login-title">
							<h2 class="text-center text-primary">Team Registeration</h2>
						</div>
						<!-- <h6 class="mb-20">Enter your new password, confirm and submit</h6> -->
						<?php  
							if(isset($message))  
							{  
								echo '<label class="text-danger">'.$message.'</label>';  
							}  
                		?>
						<form method="post">
							<div class="input-group custom">
								<input type="text" class="form-control form-control-lg" name="name" placeholder="name">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-user2"></i></span>
								</div>
							</div>
                            <div class="input-group custom">
								<input type="text" class="form-control form-control-lg" name="email" placeholder="Email">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-email"></i></span>
								</div>
							</div>
                            <div class="input-group custom">
								<input type="text" class="form-control form-control-lg" name="phone" placeholder="Phone No">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-phone-call"></i></span>
								</div>
							</div>
                            <div class="input-group custom">
								<input type="text" class="form-control form-control-lg" name="city" placeholder="City">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-map2"></i></span>
								</div>
							</div>
                            <div class="input-group custom">
								<input type="text" class="form-control form-control-lg" name="state" placeholder="State">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-map2"></i></span>
								</div>
							</div>
                            <div class="input-group custom">
								<input type="date" class="form-control form-control-lg" name="dob" placeholder="Date Of Birth">
								
							</div>
							<div class="input-group custom">
								<input type="password" class="form-control form-control-lg" name="password" placeholder="Password">
								<div class="input-group-append custom">
									<span class="input-group-text"><i class="dw dw-user-13"></i></span>
								</div>
							</div>
							<div class="row align-items-center">
								<div class="col-12">
									<div class="input-group mb-0">
												
											<input class="btn btn-primary btn-lg btn-block" name="submit" type="submit" value="Submit">
										
										<br><p>you are alredy member ? &nbsp;</p><a class="text-info" href="index.php">Login here</a>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- js -->
	<script src="../Assets/vendors/scripts/core.js"></script>
	<script src="../Assets/vendors/scripts/script.min.js"></script>
	<script src="../Assets/vendors/scripts/process.js"></script>
	<script src="../Assets/vendors/scripts/layout-settings.js"></script>
</body>
</html>