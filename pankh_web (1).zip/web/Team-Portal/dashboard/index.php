<?php 
require '../module/header.php';

	$qwr="SELECT * FROM `gallery`"; $run=mysqli_query($conn,$qwr);
	$gallary_count=mysqli_num_rows($run);

	$qwr="SELECT * FROM `gallery`"; $run=mysqli_query($conn,$qwr);
	$gallary_count=mysqli_num_rows($run);

	$qwr="SELECT * FROM `gallery` "; $run=mysqli_query($conn,$qwr);
	$contact_count=mysqli_num_rows($run);

	$qwr="SELECT * FROM `users` "; $run=mysqli_query($conn,$qwr);
	$member_count=mysqli_num_rows($run);
 ?>
<div class="row">
				<div class="col-lg-3 col-md-3 col-sm-12 mb-30">
					<div class="card-box pd-30 height-100-p">
						<div class="progress-box text-center">
							<h5 class="text-light-blue padding-top-10 h5">Total no of Gallery Photos</h5>
							<span class="d-block"><?php echo $gallary_count; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-sm-12 mb-30">
					<div class="card-box pd-30 height-100-p">
						<div class="progress-box text-center">
							<h5 class="text-light-blue padding-top-10 h5">Total no of members</h5>
							<span class="d-block"><?php echo $member_count; ?></span>
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md34 col-sm-12 mb-30">
					<div class="card-box pd-30 height-100-p">
						<div class="progress-box text-center">
							<h5 class="text-light-blue padding-top-10 h5">Total no of Projects</h5>
							<span class="d-block"><?php echo $gallary_count; ?></span>
						</div>
					</div>
				</div>
				
				<div class="col-lg-3 col-md-3 col-sm-12 mb-30">
					<div class="card-box pd-30 height-100-p">
						<div class="progress-box text-center">
							<h5 class="text-light-blue padding-top-10 h5">Contact People</h5>
							<span class="d-block"><?php echo $contact_count; ?></span>
						</div>
					</div>
				</div>
				
</div>

 <?php 
require '../module/footer.php';
  ?>