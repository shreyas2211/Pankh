<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Add Project</h2>
	</div>

	<form class="card-body" target="_self" method="post" enctype="multipart/form-data">
		<div class="control-group row">
		<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project Name</b></label>
			<div class="col-sm-12 col-md-8">
				<input type="text" name="proname"  data-original-title="" class="form-control" required>
			</div>
		</div>	<br>
		<div class="control-group row">
		<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project Description</b></label>
			<div class="col-sm-12 col-md-8">
				<input type="text" name="prodesc"  data-original-title="" class="form-control" required>
			</div>
		</div>	<br>
		<div class="control-group row">
		<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project file</b></label>
			<div class="col-sm-12 col-md-8">
				<input type="file" name="profile" data-original-title=""  class="form-control" required>
			</div>
		</div>	<br>	
		
		<div class="control-group">
		<div class="controls">
			<input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit">
		</div>
	</div>
	</form>	

<div>


<?php require '../module/footer.php'; ?>

<?php 

if (isset($_POST['submit'])) 
{
	$pro_name = $_POST['proname'];
	$pro_desc = $_POST['prodesc'];

	$file = $_FILES['profile']['name'];
	$tempfile = $_FILES['profile']['tmp_name'];

	$targetdir = "../../img/projects/".$file;
	move_uploaded_file($tempfile, $targetdir);

	$query = "INSERT INTO `projects`(`pro_name`, `file`,`description`) VALUES ('$pro_name' ,'$file','$pro_desc') ";
	$run = mysqli_query($conn,$query);

	if ($run==true) 
	{
		echo "<script>alert('data is uploaded');</script>";
		echo '<script type="text/javascript"> window.location.href = "index.php";</script>';
	}
	else{
		echo "<script>alert('data NOT uploaded');</script>";
	}
}

 ?>
