<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-9" style="margin:0px">Projects</h2>
		<a href="insert.php" class="btn btn-primary  " >Add New Project</a>
	</div>
	<div>
	<div class="container align-center col-sm-12">
		<table class="table table-hover table-bordered text-center table-responsive-md">
			<tr class="thead-dark">
				<th>Project  Name</th>
				<th>Project File</th>
				<th>Project Description</th>
				<th>Action</th>
			</tr>


<?php 


$result = $dbConn->query("SELECT * FROM projects ORDER BY pro_id DESC");
while($row = $result->fetch(PDO::FETCH_ASSOC)) { 

?>
			<tr>
				<td><?php echo $row['pro_name']; ?></td>
				<td><?php echo $row['file']?></td>
				<td><?php echo $row['description']; ?></td>
				<td><a href="delete.php?id=<?php echo $row['pro_id']; ?>" class="badge badge-danger"><span class="fa fa-trash"></span></a>
				<a href="update.php?id=<?php echo $row['pro_id']; ?>" class="badge badge-info"><span class="fa fa-pencil"></span></a></td>
			</tr>
	<?php
		}
	?>
	</div>
</div>


<?php require '../module/footer.php'; ?>