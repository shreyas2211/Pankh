<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Update Project</h2>
	</div>
	
	<?php

	if (isset($_REQUEST['id'])) {
		$id= $_REQUEST['id'];
	
		$query = "SELECT * FROM `projects` where pro_id = '$id' ";
	
		$run = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($run);
	
	?>
	
	<form class="card-body" target="_self" method="post" enctype="multipart/form-data">
			<div class="control-group row">
			<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project Name</b></label>
				<div class="col-sm-12 col-md-8">
					<input type="text" name="proname" value="<?php echo $row['pro_name']; ?>" class="form-control" required>
				</div>
			</div>	<br>

			<div class="control-group row">
			<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project Description</b></label>
				<div class="col-sm-12 col-md-8">
					<input type="text" name="prodesc" value="<?php echo $row['description']; ?>" class="form-control" required>
				</div>
			</div>	<br>
			
			<div class="control-group row">
			<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Project File</b></label>
				<div class="col-sm-12 col-md-8">
					<input type="file" name="profile" class="form-control" value="">
				</div>
			</div>
				<br>
			<div class="control-group">
			<div class="controls">
				<input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit">
			</div>
		</div>
		</form>
	
	<?php
	
		if (isset($_POST['submit'])) {

			$pro_name = $_POST['proname'];
			$pro_desc = $_POST['prodesc'];
	
	
			$filecheck  = $_FILES['profile']['tmp_name']; 
			 if ($filecheck != "") {
				unlink("../../img/projects/".$row['file']);
				 $pfile = $_FILES['profile']['name'];
				 $temp = $_FILES['profile']['tmp_name'];
				 $targetdir = "../../img/projects/".$pfile;
				 move_uploaded_file($temp, $targetdir);
			 }
			 else{ $pfile = $row['file']; }

	
			 $query2 = "UPDATE `projects` SET `pro_name`='$pro_name',`file`='$pfile',`description`='$pro_desc' WHERE pro_id =  '$id' ";
			 $run2 = mysqli_query($conn,$query2);
			 echo "<script>window.location.href='index.php' </script>";
	
		}
	
	}
	else
	{
		echo "<script>window.location.href='index.php' </script>";
	}
	
	 ?>
			

<?php require '../module/footer.php'; ?>