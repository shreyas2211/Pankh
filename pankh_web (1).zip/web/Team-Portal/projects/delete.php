<?php require '../module/config.php'; ?>

<?php 
	if (isset($_GET['id'])) 	
	{
		$id = $_REQUEST['id'];

		$dq = "SELECT * FROM `projects` WHERE pro_id = '$id'";

		$drun = mysqli_query($conn,$dq);

		$row = mysqli_fetch_array($drun);

		unlink("../../img/projects/".$row['file']);

		$query = "DELETE FROM `projects` WHERE pro_id = '$id'";
		$run = mysqli_query($conn,$query);


		if ($run == TRUE) 
		{
			echo '<script type="text/javascript">
			alert(`data successfully delete`);
			window.location.href = "index.php";
			</script>';
		}
		else{
			echo '<script type="text/javascript">
			alert(`data not delete`);
			window.location.href = "index.php";
			</script>';
		}
	}
	else{
		echo '<script type="text/javascript">
	window.location.href = "index.php";
	</script>';
	}
 ?>


<?php require '../module/footer.php'; ?>