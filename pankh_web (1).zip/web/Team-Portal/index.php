<?php  

 session_start();  

if(is_null($_SESSION["username"]))  
{  
      echo " <script>window.location='auth';</script>";
} 
else{
      echo " <script>window.location='dashboard';</script>";
}

?>

