<?php require '../module/header.php'; ?>

<?php 
	if (isset($_GET['id'])) 	
	{
		$id = $_GET['id'];
		$query = "DELETE FROM `contact` WHERE contact_id= '$id' ";
	
		$run = mysqli_query($conn,$query);
		if ($run == TRUE) 
		{
			echo '<script type="text/javascript">
			alert("successfully deleted");
			window.location.href = "index.php";
			</script>';
		}
		else{
			echo "not delete";
		}
	}
	else{
		echo '<script type="text/javascript">
	window.location.href = "index.php";
	</script>';
	}
 ?>


<?php require '../module/footer.php'; ?>