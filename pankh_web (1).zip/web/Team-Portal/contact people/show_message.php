<?php require '../module/header.php'; ?>

<a href="./index.php"><button class="btn btn-dark m-2">back</button></a>

<?php 

if (isset($_GET['id'])) 
{
	$id = $_GET['id'];
	$value = 1;
	$query = "UPDATE `contact` SET `status`= '$value'  where contact_id = '$id' ";

	$run = mysqli_query($conn,$query);

	$query2 = "SELECT * FROM `contact` where contact_id = '$id' ";

	$run2 = mysqli_query($conn,$query2);

	$row = mysqli_fetch_array($run2);
	echo '<div class="card">';
	echo "<div class='card-body p-3'> <h5><b> Name : </b>". $row['name'] ." </h5> </div>";
	echo "<div class='card-body p-3'> <h5><b> Time : </b>". $row['date_time'] ." </h5> </div>";
	echo "<div class='card-body p-3'> <h5><b> Email : </b>". $row['email'] ." </h5> </div>";
	echo "<div class='card-body p-3'> <h5><b> Subject : </b>". $row['subject'] ." </h5> </div>";
	echo "<div class='card-body p-3'> <h5><b> Message : </b>". $row['message'] ." </h5> </div>";
}
else
{
	echo '<script type="text/javascript">
	window.location.href = "index.php";
	</script>';

}

 ?>

<?php require '../module/footer.php'; ?>
