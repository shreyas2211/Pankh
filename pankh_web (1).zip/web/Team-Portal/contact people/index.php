<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Contact People List</h2>
	</div>
	<div>
	<div class="container align-center col-sm-12">
		<table class="table table-hover table-bordered text-center table-responsive-md">
			<tr class="thead-dark">
				<th>Name</th>
				<th>Date-Time</th>
				<th>Email</th>
				<th>Status</th>
				<th>Show</th>
				<th>Delete</th>
			</tr>

	<?php

	$query = "SELECT * FROM `contact`  order by `date_time` desc";

	$run = mysqli_query($conn,$query);

		while ($row = mysqli_fetch_array($run))
		{
	?>	
		
			<tr>
				<td><?php echo $row['name']; ?></td>
				<?php $date=date_create($row['date_time']) ?>
				<td><?php echo date_format($date,"d / M / Y - H:i:s") ; ?></td>
				<td><?php echo $row['email']; ?></td>
				<td><?php if ($row['status']==0) { echo "<i class='badge-pill badge-info'>unread</i>";}
				 else { echo "<i class='badge-pill badge-success'>read</i>";}  ?></td>
				<td><a href="show_message.php?id=<?php echo $row['contact_id'] ?>"><button class="badge badge  badge-warning"><i class="fa fa-eye"></i></button></a></td>
				<td><a href="delete.php?id=<?php echo $row['contact_id'] ?>"><button class="badge badge  badge-danger"><i class="fa fa-times"></i></button></a></td>
			</tr>	
	<?php
		}
	?>
	</div>


<?php require '../module/footer.php'; ?>