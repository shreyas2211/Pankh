<?php 

$dbHost = 'localhost';
$dbName = 'pankh_project';
$dbUser = 'root';
$dbPasw = '';

try {
    $dbConn = new PDO("mysql:host={$dbHost};dbname={$dbName}", $dbUser, $dbPasw);
    $dbConn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo $e->getMessage();
}

$logo_header = "../Assets/image/pankh_origanl.jpg";

$conn = mysqli_connect($dbHost,$dbUser,$dbPasw,$dbName);

 ?>
