<?php require 'config.php';
 require_once '../auth/auth_check.php' ?>		

<!DOCTYPE html>
<html>
<head>
	<!-- Basic Page Info -->
	<meta charset="utf-8">

	<!-- Seo -->

	<title>Pankh Team Portal</title>
	<meta name="description" content=" "/>
	<meta name="author" content="Tirth Makati"/>
	<link rel="base" href=""/>
	<link rel="canonical" href=""/>
	<meta rel="sitemap" type="application/xml" content=""/>
	<meta name="robots" content="index/unfollow"/>
	<meta name="googlebot" content="index/unfollow"/>
	<meta name="theme-color" content="blue"/>
	<meta name="msapplication-navbutton-color" content="#33e1ed"/>
	<meta name="apple-mobile-web-app-status-bar-style" content="#33e1ed"/>

	<!-- Site favicon -->
	<link rel="apple-touch-icon" sizes="180x180" href="../Assets/vendors/images/apple-touch-icon.png">
	<link rel="icon" type="image/png" sizes="32x32" href="../Assets/vendors/images/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="16x16" href="../Assets/vendors/images/favicon-16x16.png">

	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- Google Font -->
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
	<!-- CSS -->
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/core.css">
	<link rel="stylesheet" type="text/css" href="../Assets/src/styles/theme.css"> 
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/src/plugins/datatables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/src/plugins/datatables/css/responsive.bootstrap4.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/vendors/styles/style.css">

	<script src="//cdn.ckeditor.com/4.17.1/full/ckeditor.js"></script>
	
</head>
<body  class="sidebar-dark" >
	<div class="pre-loader">
		<div class="pre-loader-box">
			<div class="loader-logo"><img src="../../img/logo.png" height="70px" alt=""></div>
			<div class='loader-progress' id="progress_div">
				<div class='bar' id='bar1'></div>
			</div>
			<div class='percent' id='percent1'>0%</div>
			<div class="loading-text">
				Loading...
			</div>
		</div>
	</div>



	<div class="header">
			<div class="header-left">
				<div class="menu-icon dw dw-menu">
				</div>
			</div>		
				<div class="p-2 mr-auto d-none d-md-block d-md-none">
					<h2>PANKH TEAM PORTAL</h2>
					<!-- <img src="../Assets/image/aaditya_ceramic_logo.png" alt="" class="full_logo ml-auto mr-auto" > -->
				</div>
	</div>
	


	<div class="left-side-bar">
		<div class="brand-logo">
			<a href="../dashboard">
				<img src="<?php echo $logo_header; ?>" alt="" style="width:30%;" class="dark-logo ml-auto mr-auto" >
				<img src="<?php echo $logo_header; ?>" alt="" style="width:50%;" class="light-logo ml-auto mr-auto">
			</a>
			<div class="close-sidebar" data-toggle="left-sidebar-close">
				<i class="ion-close-round"></i>
			</div>
		</div>
		<div class="menu-block customscroll">
			<div class="sidebar-menu">
				<ul id="accordion-menu">
					<li>
						<a href="../dashboard" class="dropdown-toggle no-arrow ">
							<span class="micon fa fa-bar-chart"></span><span class="mtext">Dashboard</span>
						</a>
					</li>
					<li>
						<a href="../gallery" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-image"></span><span class="mtext">Gallery</span>
						</a>
					</li>
					<li>
						<a href="../projects" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-handshake-o"></span><span class="mtext">Projects</span>
						</a>
					</li>
					<li>
						<a href="../contact people" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-envelope"></span><span class="mtext">Contact Mail</span>
						</a>
					</li>
					<li>
						<a href="../site setting" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-cogs"></span><span class="mtext">Site Setting</span>
						</a>
					</li>
					<li>
						<a href="../auth/profile.php" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-user "></span><span class="mtext">Profile</span>
						</a>
					</li>
					<li>
						<a href="../auth/logout.php" class="dropdown-toggle no-arrow">
							<span class="micon fa fa-sign-out "></span><span class="mtext">Log out</span>
						</a>
					</li>
				</ul>
			</div>
			
		</div>
	
	
	
	</div>
	
	<div class="mobile-menu-overlay"></div>
		<div class="main-container">
			<div class="pd-ltr-20">
	

