<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Update image</h2>
	</div>
	
	<?php

	if (isset($_REQUEST['id'])) {
		$id= $_REQUEST['id'];
	
		$query = "SELECT * FROM `gallery` where image_id = '$id' ";
	
		$run = mysqli_query($conn,$query);
		$row = mysqli_fetch_array($run);
	
	?>
	
	<form class="card-body" target="_self" method="post" enctype="multipart/form-data">
			<div class="control-group row">
			<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Image Name</b></label>
				<div class="col-sm-12 col-md-8">
					<input type="text" name="pname" value="<?php echo $row['image_description']; ?>" class="form-control" required>
				</div>
			</div>	<br>
			
			<div class="control-group row">
			<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Image File</b></label>
				<div class="col-sm-12 col-md-8">
					<input type="file" name="pimg" class="form-control" value="">
				</div>
			</div>
			<img style="max-height: 100px ; float: right;" src="../../img/gallery/<?php echo $row['image']; ?>" >
				<br>
			<div class="control-group">
			<div class="controls">
				<input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit">
			</div>
		</div>
		</form>
	
	<?php
	
		if (isset($_POST['submit'])) {

			$image_name = $_POST['pname'];
	
	
			$filecheck  = $_FILES['pimg']['tmp_name']; 
			 if ($filecheck != "") {
				unlink("../../img/gallery/".$row['image']);
				 $pimg = $_FILES['pimg']['name'];
				 $temp = $_FILES['pimg']['tmp_name'];
				 $targetdir = "../../img/gallery/".$pimg;
				 move_uploaded_file($temp, $targetdir);
			 }
			 else{ $pimg = $row['image']; }

	
			 $query2 = "UPDATE `gallery` SET `image_description`='$image_name',`image`='$pimg' WHERE image_id =  '$id' ";
			 $run2 = mysqli_query($conn,$query2);
			 echo "<script>window.location.href='index.php' </script>";
	
		}
	
	}
	else
	{
		echo "<script>window.location.href='index.php' </script>";
	}
	
	 ?>
			

<?php require '../module/footer.php'; ?>