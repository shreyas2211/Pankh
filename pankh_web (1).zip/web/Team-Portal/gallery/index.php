<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-9" style="margin:0px">Gallery</h2>
		<a href="insert.php" class="btn btn-primary  " >Add New Images</a>
	</div>
	<div>
	<div class="container align-center col-sm-12">
		<table class="table table-hover table-bordered text-center table-responsive-md">
			<tr class="thead-dark">
				<th>Image  Name</th>
				<th>Image File</th>
				<th>Action</th>
			</tr>


<?php 


$result = $dbConn->query("SELECT * FROM gallery ORDER BY image_id DESC");
while($row = $result->fetch(PDO::FETCH_ASSOC)) { 

?>
			<tr>
				<td><?php echo $row['image_description']; ?></td>
				<td><img src="../../img/gallery/<?php echo $row['image']?>" style="height: 50px;" class="img-responsive"  alt=""></td>
				<td><a href="delete.php?id=<?php echo $row['image_id']; ?>" class="badge badge-danger"><span class="fa fa-trash"></span></a>
				<a href="update.php?id=<?php echo $row['image_id']; ?>" class="badge badge-info"><span class="fa fa-pencil"></span></a></td>
			</tr>
	<?php
		}
	?>
	</div>
</div>


<?php require '../module/footer.php'; ?>