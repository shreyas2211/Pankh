<?php require '../module/config.php'; ?>

<?php 
	if (isset($_GET['id'])) 	
	{
		$id = $_REQUEST['id'];

		$dq = "SELECT * FROM `gallery` WHERE image_id = '$id'";

		$drun = mysqli_query($conn,$dq);

		$row = mysqli_fetch_array($drun);

		unlink("../../img/gallery/".$row['image']);

		$query = "DELETE FROM `gallery` WHERE image_id = '$id'";
		$run = mysqli_query($conn,$query);


		if ($run == TRUE) 
		{
			echo '<script type="text/javascript">
			alert(`image successfully delete`);
			window.location.href = "index.php";
			</script>';
		}
		else{
			echo '<script type="text/javascript">
			alert(`image not successfully delete`);
			window.location.href = "index.php";
			</script>';
		}
	}
	else{
		echo '<script type="text/javascript">
	window.location.href = "index.php";
	</script>';
	}
 ?>


<?php require '../module/footer.php'; ?>