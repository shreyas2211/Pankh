<?php require '../module/header.php'; ?>

<div class="col-md-12 card">
	<div class="row p-4">
		<h2 class="text-center col-md-12" style="margin:0px">Add Image</h2>
	</div>

	<form class="card-body" target="_self" method="post" enctype="multipart/form-data">
		<div class="control-group row">
		<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Image Name</b></label>
			<div class="col-sm-12 col-md-8">
				<input type="text" name="imgname"  data-original-title="" class="form-control" required>
			</div>
		</div>	<br>
		<div class="control-group row">
		<label class="ccol-sm-12 col-md-4 col-form-label" for="basicinput"><b>Image file</b></label>
			<div class="col-sm-12 col-md-8">
				<input type="file" name="imgfile" data-original-title=""  class="form-control" required>
			</div>
		</div>	<br>	
		
		<div class="control-group">
		<div class="controls">
			<input type="submit" class="btn btn-primary btn-block" name="update" value="Submit">
		</div>
	</div>
	</form>	

<div>


<?php require '../module/footer.php'; ?>

<?php 

if (isset($_POST['update'])) 
{
	$image_name = $_POST['imgname'];

	$img = $_FILES['imgfile']['name'];
	$tempimg = $_FILES['imgfile']['tmp_name'];

	$targetdir = "../../img/gallery/".$img;
	move_uploaded_file($tempimg, $targetdir);

	$query = "INSERT INTO `gallery`(`image_description`, `image`) VALUES ('$image_name' ,'$img') ";
	$run = mysqli_query($conn,$query);

	if ($run==true) 
	{
		echo "<script>alert('image is uploaded');</script>";
		echo '<script type="text/javascript"> window.location.href = "index.php";</script>';
	}
	else{
		echo "<script>alert('image NOT uploaded');</script>";
	}
}

 ?>
