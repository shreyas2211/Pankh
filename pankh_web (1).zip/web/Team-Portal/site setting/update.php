<?php 	
	if(isset($_REQUEST['update']))
	{
			$about_short = $_POST['about_short'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$about_short' WHERE s_id = 1 "; 
			$run2 = mysqli_query($conn,$query2);

			$address = $_POST['address'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$address' WHERE s_id = 2 "; 
			$run2 = mysqli_query($conn,$query2);
			
			$phone = $_POST['phone'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$phone' WHERE s_id = 3 "; 
			$run2 = mysqli_query($conn,$query2);

			$email = $_POST['email'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$email' WHERE s_id = 4 "; 
			$run2 = mysqli_query($conn,$query2);

			$facebook_link = $_POST['facebook_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$facebook_link' WHERE s_id = 5 "; 
			$run2 = mysqli_query($conn,$query2);

			$instagram_link = $_POST['instagram_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$instagram_link' WHERE s_id = 6 "; 
			$run2 = mysqli_query($conn,$query2);

			$twitter_link = $_POST['twitter_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$twitter_link' WHERE s_id = 7 "; 
			$run2 = mysqli_query($conn,$query2);

			$linkedin_link = $_POST['linkedin_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$linkedin_link' WHERE s_id = 8 "; 
			$run2 = mysqli_query($conn,$query2);

			$youtube_link = $_POST['youtube_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$youtube_link' WHERE s_id = 9 "; 
			$run2 = mysqli_query($conn,$query2);

			// $web_title = $_POST['web_title'];
			// $query2 = "UPDATE `site_setting` SET `s_field_value`='$web_title' WHERE s_id = 10 "; 
			// $run2 = mysqli_query($conn,$query2);

			// $web_logo = $_POST['web_logo'];
			// $query2 = "UPDATE `site_setting` SET `s_field_value`='$web_logo' WHERE s_id = 11 "; 
			// $run2 = mysqli_query($conn,$query2);

			// $map_link = $_POST['map_link'];
			// $query2 = "UPDATE `site_setting` SET `s_field_value`='$map_link' WHERE s_id = 12 "; 
			// $run2 = mysqli_query($conn,$query2);
			
			// $js_script = $_POST['js_script'];
			// $query2 = "UPDATE `site_setting` SET `s_field_value`='$js_script' WHERE s_id = 13 "; 
			// $run2 = mysqli_query($conn,$query2);

			if(isset($_POST['popup_status'])){
				$query2 = "UPDATE `site_setting` SET `s_field_value`='1' WHERE s_id = 14 "; 
				$run2 = mysqli_query($conn,$query2);
			}
			else{
				$query2 = "UPDATE `site_setting` SET `s_field_value`='0' WHERE s_id = 14 "; 
				$run2 = mysqli_query($conn,$query2);
			}

			$popup_content = $_POST['popup_content'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$popup_content' WHERE s_id = 15 "; 
			$run2 = mysqli_query($conn,$query2);

            // popup image
            $result = $dbConn->query("SELECT * FROM site_setting where s_id = 16 ");
            while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
            $popup_image =  $row['s_field_value'];
            }
			
			$filecheck  = $_FILES['popup_image']['tmp_name']; 
			 if ($filecheck != "") {
				unlink("../../img/upload/".$popup_image);
				 $pimg = $_FILES['popup_image']['name'];
				 $temp = $_FILES['popup_image']['tmp_name'];
				 $targetdir = "../../img/upload/".$pimg;
				 move_uploaded_file($temp, $targetdir);
			 }
			 else{ $pimg = $popup_image; }

			$query2 = "UPDATE `site_setting` SET `s_field_value`='$pimg' WHERE s_id = 16 "; 
			$run2 = mysqli_query($conn,$query2);
			
			if(isset($_POST['marquee_status'])){
				$query2 = "UPDATE `site_setting` SET `s_field_value`='1' WHERE s_id = 17 "; 
				$run2 = mysqli_query($conn,$query2);
			}else{
				$query2 = "UPDATE `site_setting` SET `s_field_value`='0' WHERE s_id = 17 "; 
				$run2 = mysqli_query($conn,$query2);
			}

			$marquee_text = $_POST['marquee_text'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$marquee_text' WHERE s_id = 18 "; 
			$run2 = mysqli_query($conn,$query2);

        
	}   
	?>	