<?php require '../module/header.php'; ?>

<?php 

	// about_short
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 1 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
		$about_short =  $row['s_field_value'];
	}
	
	// address
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 2 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
		$address =  $row['s_field_value'];
	}

	// phone
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 3 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $phone =  $row['s_field_value'];
	}

	// email
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 4 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $email =  $row['s_field_value'];
	}
	
	// facebook_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 5 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$facebook_link =  $row['s_field_value'];
	}

	// instagram_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 6 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
     $instagram_link =  $row['s_field_value'];
	}

	// twitter_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 7 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$twitter_link =  $row['s_field_value'];
	}

	// linkedin_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 8 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$linkedin_link =  $row['s_field_value'];
	}

	// youtube_link
	$result = $dbConn->query("SELECT * FROM site_setting where s_id = 9 ");
	while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
	$youtube_link =  $row['s_field_value'];
	}



?>

<h1 class="text-center text-dark">Site Setting</h1><br>
<form class="" target="_self" method="post" enctype="multipart/form-data">
											

<div class="card">
	<div class="card-body card">
		<h1 class="card-title badge-pill"><u><b>About Information</u></b></h1>
		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-12 col-form-label" for="basicinput"><b>About short info.</b><p class="text-danger">this content will display on home page in about section</p></label>
			<div class="col-sm-12 col-md-12">
				<textarea name="about_short" class="" col="30" >
					<?php echo $about_short; ?>
				</textarea>
				<script>
                        CKEDITOR.replace( 'about_short' );
                </script>
			</div>
		</div><br>
	</div>
</div><br><br>


<div class="card">
<div class="card-body card">
		<br>
		<h1 class="card-title badge-pill"><u><b> Information</u></b></h1>
		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b> Address</b></label>
			<div class="col-sm-12 col-md-10">
				<textarea name="address" id="" rows="3" class="form-control"><?php echo $address; ?></textarea>
			</div>
		</div><br>

		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b> Email</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $email; ?>" name="email" data-original-title="" class="form-control" required>
			</div>
		</div><br>

		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b> phone</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $phone; ?>" name="phone" data-original-title="" class="form-control" required>
			</div>
		</div><br>
	</div>
</div><br><br>

<div class="card">
	<div class="card-body card">
		<h1 class="card-title badge-pill"><u><b>Social Media Links</u></b></h1	>
		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>Instagram Link</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $instagram_link; ?>" name="instagram_link" data-original-title="" class="form-control" required>
			</div>
		</div><br>

		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>Facebook Link</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $facebook_link; ?>" name="facebook_link" data-original-title="" class="form-control" required>
			</div>
		</div><br>

		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>Linked in Link</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $linkedin_link; ?>" name="linkedin_link" data-original-title="" class="form-control" required>
			</div>
		</div><br>

		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>Twitter Link</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $twitter_link; ?>" name="twitter_link" data-original-title="" class="form-control" required>
			</div>
		</div><br>
		
		<div class="card-text control-group row">
			<label class="ccol-sm-12 col-md-2 col-form-label" for="basicinput"><b>Youtube Link</b></label>
			<div class="col-sm-12 col-md-10">
				<input type="text" value="<?php echo $youtube_link; ?>" name="youtube_link" data-original-title="" class="form-control" required>
			</div>
		</div><br><br>
</div>	
	</div>
</div>
												
	<div class="container mt-5 mb-5 control-group">
		<div class="controls">
			<input type="submit" class="btn btn-primary btn-block" name="update" value="Update">
		</div>
	</div> 
</form>


<?php 	
	if(isset($_POST['update']))
	{
			$about_short = $_POST['about_short'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$about_short' WHERE s_id = 1 "; 
			$run2 = mysqli_query($conn,$query2);

			$address = $_POST['address'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$address' WHERE s_id = 2 "; 
			$run2 = mysqli_query($conn,$query2);
			
			$phone = $_POST['phone'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$phone' WHERE s_id = 3 "; 
			$run2 = mysqli_query($conn,$query2);

			$email = $_POST['email'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$email' WHERE s_id = 4 "; 
			$run2 = mysqli_query($conn,$query2);

			$facebook_link = $_POST['facebook_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$facebook_link' WHERE s_id = 5 "; 
			$run2 = mysqli_query($conn,$query2);

			$instagram_link = $_POST['instagram_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$instagram_link' WHERE s_id = 6 "; 
			$run2 = mysqli_query($conn,$query2);

			$twitter_link = $_POST['twitter_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$twitter_link' WHERE s_id = 7 "; 
			$run2 = mysqli_query($conn,$query2);

			$linkedin_link = $_POST['linkedin_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$linkedin_link' WHERE s_id = 8 "; 
			$run2 = mysqli_query($conn,$query2);

			$youtube_link = $_POST['youtube_link'];
			$query2 = "UPDATE `site_setting` SET `s_field_value`='$youtube_link' WHERE s_id = 9 "; 
			$run2 = mysqli_query($conn,$query2);

			if ($run2==true) 
			{
				echo "<script>alert('data is updated');</script>";
				echo '<script type="text/javascript"> window.location.href = "index.php";</script>';
			}
			else{
				echo "<script>alert('data NOT update');</script>";
			}

			
	}   
	?>	


<?php require '../module/footer.php'; ?>
