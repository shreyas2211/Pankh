<?php include 'header.php'; ?>


<div class="tb-space"></div>

<div class="container">
    <section class="probootstrap-section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center section-heading probootstrap-animate" data-animate-effect="fadeIn">
              <h2>Gallery</h2>
              <p class="lead">showcase of our efforts</p>
            </div>
          </div>

          
          <div class="row">
          <?php $result = $dbConn->query("SELECT * FROM gallery ");
            while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
          ?>
            <div class="col-md-3 col-sm-6 col-xs-6 probootstrap-animate">
              <a href="#" class="probootstrap-team">
                <img src="img/gallery/<?php echo $row['image']; ?>" alt="" class="img-responsive">
                <div class="probootstrap-team-info">
                  <h3><?php echo $row['image_description']; ?></h3>
                </div>
              </a>
            </div>
            
            <div class="clearfix visible-sm-block visible-xs-block"></div>
          <?php } ?>    
        
          </div>
        </div>
      </section>

</div>

</div>


<?php include 'footer.php'; ?>