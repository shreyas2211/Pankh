<?php include 'header.php'; ?>


<div class="tb-space"></div>

<div class="container">
    <section class="probootstrap-section">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center section-heading probootstrap-animate" data-animate-effect="fadeIn">
              <h2> Projects</h2>
              <p class="lead">showcase of our activities</p>
            </div>
          </div>
          <section class="probootstrap-section">
        <div class="container">
          <div class="row">
          <?php $result = $dbConn->query("SELECT * FROM projects ");
            while($row = $result->fetch(PDO::FETCH_ASSOC)) { 
          ?>
            <div class="col-md-4 col-sm-6 col-xs-6 col-xxs-12 probootstrap-animate" data-animate-effect="fadeIn">
              <div class="probootstrap-image-text-block probootstrap-cause">
                
                <div class="probootstrap-cause-inner">
               
                  <h2><?php echo $row['pro_name']; ?></h2>
                  <div class="probootstrap-date"><i class="icon-calendar"></i><?php echo $row['time']; ?></div>  
                  
                  <p><?php echo $row['description']; ?></p>
                  <p><a href="img/projects/<?php echo $row['file']; ?>" class="btn btn-primary btn-black">Download</a></p>
                </div>
              </div>
            </div>
            <div class="clearfix visible-sm-block visible-xs-block"></div>
            <?php }?>
          </div>
        </div>
      </section>
        </div>
    </section>
</div>

<?php include 'footer.php';?>