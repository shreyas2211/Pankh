<?php include 'header.php'; ?>

<section class="probootstrap-hero" style="background:linear-gradient(0deg, rgba(0 0 0 / 54%), rgba(0 0 0 / 89%)) , url(img/pankh_main.jpg) no-repeat"  data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="probootstrap-slider-text probootstrap-animate" data-animate-effect="fadeIn">
                <h1 class="probootstrap-heading probootstrap-animate">Pankh <span>nanhe parindo ki unchi udaan...</span></h1>
                <p class="probootstrap-animate"><a href="#" class="btn btn-primary btn-lg"> About Us</a></p>
              </div>
            </div>
          </div>
        </div>
        <div class="probootstrap-service-intro">
          <div class="container">
            <div class="probootstrap-service-intro-flex">
              <div class="item probootstrap-animate" data-animate-effect="fadeIn">
                <div class="icon">
                  <i class="icon-gift"></i>
                </div>
                <div class="text">
                  <h2>Give Foods & Cloths</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
                  <p><a href="#">Lear More</a></p>
                </div>
              </div>
              <div class="item probootstrap-animate" data-animate-effect="fadeIn">
                <div class="icon">
                  <i class="icon-heart"></i>
                </div>
                <div class="text">
                  <h2>Become Volunteer</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
                  <p><a href="#">Lear More</a></p>
                </div>
              </div>
              <div class="item probootstrap-animate" data-animate-effect="fadeIn">
                <div class="icon">
                  <i class="icon-graduation-cap"></i>
                </div>
                <div class="text">
                  <h2>Give Scholarship</h2>
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
                  <p><a href="#">Lear More</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>


      <section class="probootstrap-section ">
        <div class="container">
          <div class="row">
            <div class="col-md-12 text-center section-heading probootstrap-animate">
              <h2>About Us</h2>
              <p class="lead"><?php echo $about_short; ?></p>
            </div>
          </div>
        </div>
      </section>

<?php include 'footer.php'; ?>